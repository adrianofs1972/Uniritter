SELECT `continent`, AVG(`surface_area`) AS `mean_sa`
FROM `countries`
GROUP BY `continent`